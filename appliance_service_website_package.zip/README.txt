WASHING MACHINE & FREEZER REPAIR CENTER WEBSITE

Files:
- index.html: complete, responsive website. The supplied logo is embedded in the HTML, so no separate image file is required.

How to preview:
1. Open the folder and double-click index.html.
2. It should open in Chrome or your default browser.

Before publishing, check these details:
- Phone: 9740288957
- Location: Kritipur, Kathmandu, Nepal
- WhatsApp link: currently uses Nepal country code +977 and the phone number above.
- Only use “Authorized Service Center” if you have official authorization from the relevant brands.

To publish with GitHub Pages:
1. Sign in to GitHub and open your website repository.
2. Upload index.html (replace the existing file if needed).
3. Commit the changes.
4. In Settings > Pages, choose the main branch and root folder, then save.
5. Wait for GitHub Pages to publish the site.
